%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Code Update: 05/27/2024
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) Reference: 
% Goo, J., Sakhanenko, L., & Zhu, D. C. (2024).
% A finite difference approach to brain anatomical connectivity over time
% Submitted
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation example under H0 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Theorem 1 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nx=40; ny=40; nz=40; nt=4; n=nx*ny*nz; % sample size= # of spatial points
h=0.0167;  % The bandwidth h should be within approximately 2epsilon/6=0.1/6.
beta=n*h^6;

x0=[0.5*cos(0.3);0.5*sin(0.3);0.5]; % initial points

rng(1234) % random seed
dir=48;% the number of gradient directions
[B, ~]=rotateb_new(dir); % create a 48*6 B-matrix

y_array=cell(nt,1); % each cell, a (nx*ny*nz)*48 matrix 
DD_array=cell(nt,1); % each cell, a 6*(nx*ny*nz) matrix 

for q0=1:nt
    [y_array{q0,1},~]=init_template1b(nx,ny,nz,B); 
    DD_array{q0,1}=dtilda(y_array{q0,1},B);  % ols of the diffusion tensor D 
end

delta=0.02; steps=15; % Euler's method 

[xnhat, dnhat, dvdd, dddx, trH]=xnhat_all2(nx,ny,nz,nt,DD_array,x0,delta,steps,beta); % estimate the integral curve, etc
dhat_array=dnhat_all_prep(DD_array(:,1),nx,ny,nz,nt,beta); 
gam0gam0t=gamgamt_all_prep2(nx,ny,nz,nt,dhat_array,xnhat,steps,beta,y_array(:,1),B); 

[muhat,chat]=xnhatconf(dnhat,dvdd,dddx,gam0gam0t(:,1),trH,delta,steps,beta,nt);

% For graph

for ind=1:nt
    plot3(xnhat{ind}(1,:),xnhat{ind}(2,:),xnhat{ind}(3,:),'b') % estimated curves over time 1 to time nt
    hold on
end

view([0 90])

alpha=0.05; 
figure(); 
trackplot(xnhat{1},muhat{1},chat{1},alpha,nx,ny,nz,h,steps,'c') ; % 95% confindence ellipsoids at the 1st time point


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Corollary 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a1=[-1;-1;-1;3];
a2=[-1;-1;3;-1]; 
a3=[-1;3;-1;-1]; 
a4=[3;-1;-1;-1];
a5=[-1;-1;1;1];

w=a1(1)*xnhat{1,1}+a1(2)*xnhat{2,1}+a1(3)*xnhat{3,1}+a1(4)*xnhat{4,1};
wnhat=sqrt(n*h^2)*sum(w,1);

mu=a1(1)*muhat{1,1}+a1(2)*muhat{2,1}+a1(3)*muhat{3,1}+a1(4)*muhat{4,1};
muvec=sum(mu,1);

cov=a1(1)^2*chat{1,1}+a1(2)^2*chat{2,1}+a1(3)^2*chat{3,1}+a1(4)^2*chat{4,1};
covhat=zeros((1+steps),(1+steps));
for j=1:(1+steps)
    for k=1:(1+steps)
        covhat(j,k)=ones(1,3)*cov(:,:,j,k)*ones(3,1);
    end
end
diff=(wnhat(:,2:steps+1)-muvec(:,2:steps+1))';
P=covhat(2:steps+1,2:steps+1);
[U S V]=svds(P,2); 
chi_null_a1=diff'*pinv(U*S*V',10^-6)*diff;

% 

w=a2(1)*xnhat{1,1}+a2(2)*xnhat{2,1}+a2(3)*xnhat{3,1}+a2(4)*xnhat{4,1};
wnhat=sqrt(n*h^2)*sum(w,1);

mu=a2(1)*muhat{1,1}+a2(2)*muhat{2,1}+a2(3)*muhat{3,1}+a2(4)*muhat{4,1};
muvec=sum(mu,1);

cov=a2(1)^2*chat{1,1}+a2(2)^2*chat{2,1}+a2(3)^2*chat{3,1}+a2(4)^2*chat{4,1};
covhat=zeros((1+steps),(1+steps));
for j=1:(1+steps)
    for k=1:(1+steps)
        covhat(j,k)=ones(1,3)*cov(:,:,j,k)*ones(3,1);
    end
end
diff=(wnhat(:,2:steps+1)-muvec(:,2:steps+1))';
P=covhat(2:steps+1,2:steps+1);
[U S V]=svds(P,2); 
chi_null_a2=diff'*pinv(U*S*V',10^-6)*diff;

%

w=a3(1)*xnhat{1,1}+a3(2)*xnhat{2,1}+a3(3)*xnhat{3,1}+a3(4)*xnhat{4,1};
wnhat=sqrt(n*h^2)*sum(w,1);

mu=a3(1)*muhat{1,1}+a3(2)*muhat{2,1}+a3(3)*muhat{3,1}+a3(4)*muhat{4,1};
muvec=sum(mu,1);

cov=a3(1)^2*chat{1,1}+a3(2)^2*chat{2,1}+a3(3)^2*chat{3,1}+a3(4)^2*chat{4,1};
covhat=zeros((1+steps),(1+steps));
for j=1:(1+steps)
    for k=1:(1+steps)
        covhat(j,k)=ones(1,3)*cov(:,:,j,k)*ones(3,1);
    end
end
diff=(wnhat(:,2:steps+1)-muvec(:,2:steps+1))';
P=covhat(2:steps+1,2:steps+1);
[U S V]=svds(P,2); 
chi_null_a3=diff'*pinv(U*S*V',10^-6)*diff;

%

w=a4(1)*xnhat{1,1}+a4(2)*xnhat{2,1}+a4(3)*xnhat{3,1}+a4(4)*xnhat{4,1};
wnhat=sqrt(n*h^2)*sum(w,1);

mu=a4(1)*muhat{1,1}+a4(2)*muhat{2,1}+a4(3)*muhat{3,1}+a4(4)*muhat{4,1};
muvec=sum(mu,1);

cov=a4(1)^2*chat{1,1}+a4(2)^2*chat{2,1}+a4(3)^2*chat{3,1}+a4(4)^2*chat{4,1};
covhat=zeros((1+steps),(1+steps));
for j=1:(1+steps)
    for k=1:(1+steps)
        covhat(j,k)=ones(1,3)*cov(:,:,j,k)*ones(3,1);
    end
end
diff=(wnhat(:,2:steps+1)-muvec(:,2:steps+1))';
P=covhat(2:steps+1,2:steps+1);
[U S V]=svds(P,2); 
chi_null_a4=diff'*pinv(U*S*V',10^-6)*diff;

%

w=a5(1)*xnhat{1,1}+a5(2)*xnhat{2,1}+a5(3)*xnhat{3,1}+a5(4)*xnhat{4,1};
wnhat=sqrt(n*h^2)*sum(w,1);

mu=a5(1)*muhat{1,1}+a5(2)*muhat{2,1}+a5(3)*muhat{3,1}+a5(4)*muhat{4,1};
muvec=sum(mu,1);

cov=a5(1)^2*chat{1,1}+a5(2)^2*chat{2,1}+a5(3)^2*chat{3,1}+a5(4)^2*chat{4,1};
covhat=zeros((1+steps),(1+steps));
for j=1:(1+steps)
    for k=1:(1+steps)
        covhat(j,k)=ones(1,3)*cov(:,:,j,k)*ones(3,1);
    end
end
diff=(wnhat(:,2:steps+1)-muvec(:,2:steps+1))';
P=covhat(2:steps+1,2:steps+1);
[U S V]=svds(P,2); 
chi_null_a5=diff'*pinv(U*S*V',10^-6)*diff;



chi_null_a1
chi_null_a2
chi_null_a3
chi_null_a4
chi_null_a5

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation example under H1 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nx=40; ny=40; nz=40; nt=4; n=nx*ny*nz; % sample size= # of spatial points
mt=2;
h=0.0167;  % The bandwidth h should be within approximately 2epsilon/6=0.1/6.
beta=n*h^6;

x0=[0.5*cos(0.3);0.5*sin(0.3);0.5]; % initial points

rng(1234) % random seed
dir=48;% the number of gradient directions
[B, ~]=rotateb_new(dir); % create a 48*6 B-matrix

for ind=1:mt
    [y_array{ind,1},~]=init_template1b(nx,ny,nz,B); % keep the null until mt time points
    DD_array{ind,1}=dtilda(y_array{ind,1},B);  % ols of D  
end

yvar=0.48;

for ind=(mt+1):nt
    [y_array{ind,1},~]=init_template2b(nx,ny,nz,B,yvar); % change curves 
    DD_array{ind,1}=dtilda(y_array{ind,1},B);  % ols of D  
end

delta=0.02; steps=15; % Euler's method 

[xnhat, dnhat, dvdd, dddx, trH]=xnhat_all2(nx,ny,nz,nt,DD_array,x0,delta,steps,beta); % estimate the integral curve, etc
dhat_array=dnhat_all_prep(DD_array(:,1),nx,ny,nz,nt,beta); 
gam0gam0t=gamgamt_all_prep2(nx,ny,nz,nt,dhat_array,xnhat,steps,beta,y_array(:,1),B); 

[muhat,chat]=xnhatconf(dnhat,dvdd,dddx,gam0gam0t(:,1),trH,delta,steps,beta,nt);

% For graph

for ind=1:mt
    plot3(xnhat{ind}(1,:),xnhat{ind}(2,:),xnhat{ind}(3,:), 'b') % estimated curves over time 1 to time mt
    hold on
end

for ind=(mt+1):nt
    plot3(xnhat{ind}(1,:),xnhat{ind}(2,:),xnhat{ind}(3,:), 'r') % estimated curves over time 1 to time mt
    hold on
end

view([0 90])

alpha=0.05; 
figure(); 
trackplot(xnhat{1},muhat{1},chat{1},alpha,nx,ny,nz,h,steps,'c') ; % 95% confindence ellipsoids at the 1st time point


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Corollary 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a1=[-1;-1;-1;3];
a2=[-1;-1;3;-1]; 
a3=[-1;3;-1;-1]; 
a4=[3;-1;-1;-1];
a5=[-1;-1;1;1];

w=a1(1)*xnhat{1,1}+a1(2)*xnhat{2,1}+a1(3)*xnhat{3,1}+a1(4)*xnhat{4,1};
wnhat=sqrt(n*h^2)*sum(w,1);

mu=a1(1)*muhat{1,1}+a1(2)*muhat{2,1}+a1(3)*muhat{3,1}+a1(4)*muhat{4,1};
muvec=sum(mu,1);

cov=a1(1)^2*chat{1,1}+a1(2)^2*chat{2,1}+a1(3)^2*chat{3,1}+a1(4)^2*chat{4,1};
covhat=zeros((1+steps),(1+steps));
for j=1:(1+steps)
    for k=1:(1+steps)
        covhat(j,k)=ones(1,3)*cov(:,:,j,k)*ones(3,1);
    end
end
diff=(wnhat(:,2:steps+1)-muvec(:,2:steps+1))';
P=covhat(2:steps+1,2:steps+1);
[U S V]=svds(P,2); 
chi_alt_a1=diff'*pinv(U*S*V',10^-6)*diff;

%

w=a2(1)*xnhat{1,1}+a2(2)*xnhat{2,1}+a2(3)*xnhat{3,1}+a2(4)*xnhat{4,1};
wnhat=sqrt(n*h^2)*sum(w,1);

mu=a2(1)*muhat{1,1}+a2(2)*muhat{2,1}+a2(3)*muhat{3,1}+a2(4)*muhat{4,1};
muvec=sum(mu,1);

cov=a2(1)^2*chat{1,1}+a2(2)^2*chat{2,1}+a2(3)^2*chat{3,1}+a2(4)^2*chat{4,1};
covhat=zeros((1+steps),(1+steps));
for j=1:(1+steps)
    for k=1:(1+steps)
        covhat(j,k)=ones(1,3)*cov(:,:,j,k)*ones(3,1);
    end
end
diff=(wnhat(:,2:steps+1)-muvec(:,2:steps+1))';
P=covhat(2:steps+1,2:steps+1);
[U S V]=svds(P,2); 
chi_alt_a2=diff'*pinv(U*S*V',10^-6)*diff;

%

w=a3(1)*xnhat{1,1}+a3(2)*xnhat{2,1}+a3(3)*xnhat{3,1}+a3(4)*xnhat{4,1};
wnhat=sqrt(n*h^2)*sum(w,1);

mu=a3(1)*muhat{1,1}+a3(2)*muhat{2,1}+a3(3)*muhat{3,1}+a3(4)*muhat{4,1};
muvec=sum(mu,1);

cov=a3(1)^2*chat{1,1}+a3(2)^2*chat{2,1}+a3(3)^2*chat{3,1}+a3(4)^2*chat{4,1};
covhat=zeros((1+steps),(1+steps));
for j=1:(1+steps)
    for k=1:(1+steps)
        covhat(j,k)=ones(1,3)*cov(:,:,j,k)*ones(3,1);
    end
end
diff=(wnhat(:,2:steps+1)-muvec(:,2:steps+1))';
P=covhat(2:steps+1,2:steps+1);
[U S V]=svds(P,2); 
chi_alt_a3=diff'*pinv(U*S*V',10^-6)*diff;

%

w=a4(1)*xnhat{1,1}+a4(2)*xnhat{2,1}+a4(3)*xnhat{3,1}+a4(4)*xnhat{4,1};
wnhat=sqrt(n*h^2)*sum(w,1);

mu=a4(1)*muhat{1,1}+a4(2)*muhat{2,1}+a4(3)*muhat{3,1}+a4(4)*muhat{4,1};
muvec=sum(mu,1);

cov=a4(1)^2*chat{1,1}+a4(2)^2*chat{2,1}+a4(3)^2*chat{3,1}+a4(4)^2*chat{4,1};
covhat=zeros((1+steps),(1+steps));
for j=1:(1+steps)
    for k=1:(1+steps)
        covhat(j,k)=ones(1,3)*cov(:,:,j,k)*ones(3,1);
    end
end
diff=(wnhat(:,2:steps+1)-muvec(:,2:steps+1))';
P=covhat(2:steps+1,2:steps+1);
[U S V]=svds(P,2); 
chi_alt_a4=diff'*pinv(U*S*V',10^-6)*diff;

%

w=a5(1)*xnhat{1,1}+a5(2)*xnhat{2,1}+a5(3)*xnhat{3,1}+a5(4)*xnhat{4,1};
wnhat=sqrt(n*h^2)*sum(w,1);

mu=a5(1)*muhat{1,1}+a5(2)*muhat{2,1}+a5(3)*muhat{3,1}+a5(4)*muhat{4,1};
muvec=sum(mu,1);

cov=a5(1)^2*chat{1,1}+a5(2)^2*chat{2,1}+a5(3)^2*chat{3,1}+a5(4)^2*chat{4,1};
covhat=zeros((1+steps),(1+steps));
for j=1:(1+steps)
    for k=1:(1+steps)
        covhat(j,k)=ones(1,3)*cov(:,:,j,k)*ones(3,1);
    end
end
diff=(wnhat(:,2:steps+1)-muvec(:,2:steps+1))';
P=covhat(2:steps+1,2:steps+1);
[U S V]=svds(P,2); 
chi_alt_a5=diff'*pinv(U*S*V',10^-6)*diff;

chi_alt_a1
chi_alt_a2
chi_alt_a3
chi_alt_a4
chi_alt_a5

chi2inv(0.95,2)
