function mat=dnhat_all_prep(DD_array,nx,ny,nz,nt,beta)
n=nx*ny*nz;
h=(n/beta)^(-1/6);

mat=cell(nt,1);  

for q0=1:nt
    mat{q0}=zeros(6, nx*ny*nz);
end


cut1=16*h^2;
cut2=1/(2*h^2);
factor=1/(((2*pi)^(1.5))*n*(h^3));

for q0=1:nt
    for i0=1:nx
        for j0=1:ny
            for k0=1:nz
                u=[i0/nx, j0/ny, k0/nz];
                ind0=nx*ny*(k0-1)+nx*(j0-1)+i0;
                
                    for i=1:nx
                        for j=1:ny
                            for k=1:nz                            
                                inner=(u(1)-i/nx)^2+(u(2)-j/ny)^2+(u(3)-k/nz)^2;
                                if inner<=cut1
                                    kernel=exp(-cut2*inner);
                                    ind=nx*ny*(k-1)+nx*(j-1)+i;
                                    mat{q0}(:,ind0)=mat{q0}(:,ind0)+kernel*DD_array{q0}(:,ind);                                     
                                end
                            end
                        end
                    end
            end
        end
    end
    mat{q0}=mat{q0}*factor; % nh^(d+1)  
end
 

end