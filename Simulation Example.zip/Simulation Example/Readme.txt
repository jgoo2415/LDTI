Code Update: 05/27/2024
Author: Juna Goo (junagoo@boisestate.edu)

(1) SISP folder contains MATLAB simulation codes for the paper titled 
"A chi-square type test for time-invariant fiber pathways of the brain".
 
Reference: 
Goo, J., Sakhanenko, L., & Zhu, D. C. (2022). 
A chi-square type test for time-invariant fiber pathways of the brain. 
Statistical Inference for Stochastic Processes, 25 (3), 449-469.

main.m will generate simulation examples under H0 and under H1, respectively.

(2) SPL folder contains MATLAB simulation codes for the paper titled 
"A finite difference approach to brain anatomical connectivity over time".

Reference: 
Goo, J., Sakhanenko, L., & Zhu, D. C. (2024). 
A finite difference approach to brain anatomical connectivity over time.
Submitted.

main.m will generate simulation examples under H0 and under H1, respectively.
