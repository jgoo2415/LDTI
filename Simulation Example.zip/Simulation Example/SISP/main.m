%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) Reference: 
% Goo, J., Sakhanenko, L., & Zhu, D. C. (2022). 
% A chi-square type test for time-invariant fiber pathways of the brain. 
% Statistical Inference for Stochastic Processes, 25 (3), 449-469.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation example under H0 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Theorem 1 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nx=20; ny=20; nz=20; nt=19; n=nx*ny*nz*nt;  % sample size= # of spatial points multiplied by # of time points
h=0.0167;  % The bandwidth h should be within approximately 2epsilon/6=0.1/6.
beta=n*h^7;

t=(1:1:nt)/nt; % equally spaced time points

x0=[0.5*cos(0.3);0.5*sin(0.3);0.5]; % initial value

rng(1234) % random seed
dir=48;% the number of gradient directions
[B, ~]=rotateb_new(dir); % create a 48*6 B-matrix

y_array=cell(nt,1); % each cell, a (nx*ny*nz)*48 matrix 
DD_array=cell(nt,1); % each cell, a 6*(nx*ny*nz) matrix 

for q0=1:nt
    [y_array{q0,1},~]=init_template1b(nx,ny,nz,B); 
    DD_array{q0,1}=dtilda(y_array{q0,1},B);  % ols of the diffusion tensor D 
end

delta=0.02; steps=15; % Euler's method 

[xnhat2, dnhat2, dvdd2, dddx2, trH2]=xnhat_all2_Goo(nx,ny,nz,nt,DD_array,x0,t,delta,steps,beta); % estimate the integral curve, etc
dhat_array2=dnhat_all_prep_Goo(DD_array(:,1),nx,ny,nz,nt,beta); % for a residual tensor
gam0gam0t2=gamgamt_all_prep2_Goo(nx,ny,nz,nt,dhat_array2,xnhat2,t,steps,beta,y_array(:,1),B); % gamma_0 gamma'_0 estimate in the covariance function

[muhat2,chat2]=xnhatconf_Goo(dnhat2,dvdd2,dddx2,gam0gam0t2(:,1),trH2,delta,steps,beta,nt); % estimate the mean and covariance function

% For graph

for ind=1:nt
    plot3(xnhat2{ind}(1,:),xnhat2{ind}(2,:),xnhat2{ind}(3,:),'b') % estimated curves over time 1 to time nt
    hold on
end

view([0 90])

alpha=0.05; 
figure(); 
trackplot2(xnhat2{1},muhat2{1},chat2{1},alpha,nx,ny,nz,nt,h,steps,'c') ; % 95% confindence ellipsoids at the 1st time point


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Theorem 2 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

chi_null=zeros(1,3);

a=1; b=nt; % b>a+6 and nt is odd for the use of Simpson's 1/3 rule
wa=cell(1,3); wb=cell(1,3); wt=cell(1,3); % weight functions
wa{1}=[t(a);t(a);t(a)]; wb{1}=[t(b);t(b);t(b)]; wt{1}=ones(3,nt);  % linear 
wa{2}=[exp(t(a));exp(t(a));exp(t(a))]; wb{2}=[exp(t(b));exp(t(b));exp(t(b))]; wt{2}=[exp(t);exp(t);exp(t)]; % exponential
wa{3}=[1;1;1]; wb{3}=[1;1;1]; wt{3}=zeros(3,nt); % constant

for rep=1:3
    what=W0_Goo(xnhat2,a,b,t,steps,wa{rep},wb{rep},wt{rep},n,h);
    covhat=cov0_Goo(chat2,a,b,steps,wa{rep},wb{rep});
    meanhat=mu0_Goo(muhat2,a,b,t,steps,wa{rep},wb{rep},wt{rep});
    diff=what(2:steps+1,1)-meanhat(2:steps+1,1);
    P=covhat(2:steps+1,2:steps+1);
    [U S V]=svds(P,2);        
    chi_null(1,rep)=diff'*pinv(U*S*V',10^-6)*diff;
end 

chi_null % the value of test statistic


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation example under H1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Theorem 1 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nx=20; ny=20; nz=20; nt=19; n=nx*ny*nz*nt;  % sample size= # of spatial points multiplied by # of time points
mt=9;
h=0.0167;  % The bandwidth h should be within approximately 2epsilon/6=0.1/6.
beta=n*h^7;

h1=(n/beta)^(-1/9); % For the first derivative of the diffusion tensor
h2=(n/beta)^(-1/10); % For the second derivative of the diffusion tensor

t=(1:1:nt)/nt; % equally spaced time points

x0=[0.5*cos(0.3);0.5*sin(0.3);0.5]; % initial points

rng(1234) % random seed
dir=48;% the number of gradient directions
[B, ~]=rotateb_new(dir); % create a 48*6 B-matrix

y_array=cell(nt,1); % each cell, a (nx*ny*nz)*48 matrix 
DD_array=cell(nt,1); % each cell, a 6*(nx*ny*nz) matrix 

for ind=1:mt
    [y_array{ind,1},~]=init_template1b(nx,ny,nz,B); % keep the null until mt time points
    DD_array{ind,1}=dtilda(y_array{ind,1},B);  % ols of D  
end

yvar=0.45;

for ind=(mt+1):nt
    [y_array{ind,1},~]=init_template2b(nx,ny,nz,B,yvar); % change curves 
    DD_array{ind,1}=dtilda(y_array{ind,1},B);  % ols of D  
end


delta=0.02; steps=15; % Euler's method 

[xnhat2, dnhat2, dvdd2, dddx2, trH2]=xnhat_all2_Goo(nx,ny,nz,nt,DD_array,x0,t,delta,steps,beta); % estimate the integral curve, etc
dhat_array2=dnhat_all_prep_Goo(DD_array(:,1),nx,ny,nz,nt,beta); % for a residual tensor
gam0gam0t2=gamgamt_all_prep2_Goo(nx,ny,nz,nt,dhat_array2,xnhat2,t,steps,beta,y_array(:,1),B); % gamma_0 gamma'_0 estimate in the covariance function

[muhat2,chat2]=xnhatconf_Goo(dnhat2,dvdd2,dddx2,gam0gam0t2(:,1),trH2,delta,steps,beta,nt); % estimate the mean and covariance function

% For graph

for ind=1:mt
    plot3(xnhat2{ind}(1,:),xnhat2{ind}(2,:),xnhat2{ind}(3,:),'b') % estimated curves over time 1 to time mt
    hold on
end

for ind=(mt+1):nt
    plot3(xnhat2{ind}(1,:),xnhat2{ind}(2,:),xnhat2{ind}(3,:),'r') % estimated curves over time mt+1 to nt
    hold on
end

view([0 90])

alpha=0.05; 
figure(); 
trackplot2(xnhat2{1},muhat2{1},chat2{1},alpha,nx,ny,nz,nt,h,steps,'c') ; % 95% confindence ellipsoids at the 1st time point


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Theorem 2 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

chi_alt=zeros(1,3);

a=1; b=nt; % b>a+6 and nt is odd for the use of Simpson's 1/3 rule
wa=cell(1,3); wb=cell(1,3); wt=cell(1,3); % weight functions
wa{1}=[t(a);t(a);t(a)]; wb{1}=[t(b);t(b);t(b)]; wt{1}=ones(3,nt);  % linear 
wa{2}=[exp(t(a));exp(t(a));exp(t(a))]; wb{2}=[exp(t(b));exp(t(b));exp(t(b))]; wt{2}=[exp(t);exp(t);exp(t)]; % exponential
wa{3}=[1;1;1]; wb{3}=[1;1;1]; wt{3}=zeros(3,nt); % constant


for rep=1:3
    what=W0_Goo(xnhat2,a,b,t,steps,wa{rep},wb{rep},wt{rep},n,h);
    covhat=cov0_Goo(chat2,a,b,steps,wa{rep},wb{rep});
    meanhat=mu0_Goo(muhat2,a,b,t,steps,wa{rep},wb{rep},wt{rep});
    diff=what(2:steps+1,1)-meanhat(2:steps+1,1);
    P=covhat(2:steps+1,2:steps+1);
    [U S V]=svds(P,2);        
    chi_alt(1,rep)=diff'*pinv(U*S*V',10^-6)*diff;
end 

chi_alt % the value of test statistic


