function [y, vmat]=init_template1b(nx,ny,nz,B)
n=nx*ny*nz;  
loc=zeros(n,3); % spatial location
mat=zeros(n,6); % six distinct elements of the diffusion tensor at given spatial location
vmat=zeros(n,3); % eigenvector of the diffusion tensor associated with the largest eigenvalue

for i=1:nx
    for j=1:ny
        for k=1:nz

            loc(nx*ny*(k-1)+nx*(j-1)+i,:)=[i/nx, j/ny, k/nz]; % spatial location
            v1=sqrt((i/nx)^2+(j/ny)^2); 

            epsilon=0.05; % thickness of the fiber bundle 
          if (abs(k/nz-0.5)<epsilon) && (abs(v1-0.5)<epsilon)
             
            myv=[(j/ny)/v1 (i/nx)/v1 0; -(i/nx)/v1 (j/ny)/v1 0; 0 0 1];
            mym=myv*diag([10,2,1])*myv'; % eigendecomposition of the diffusion tensor

            mat(nx*ny*(k-1)+nx*(j-1)+i,1)=mym(1,1);
            mat(nx*ny*(k-1)+nx*(j-1)+i,2)=mym(1,2);
            mat(nx*ny*(k-1)+nx*(j-1)+i,3)=mym(1,3);
            mat(nx*ny*(k-1)+nx*(j-1)+i,4)=mym(2,2);
            mat(nx*ny*(k-1)+nx*(j-1)+i,5)=mym(2,3);
            mat(nx*ny*(k-1)+nx*(j-1)+i,6)=mym(3,3);

            vmat(nx*ny*(k-1)+nx*(j-1)+i,1)=myv(1,1);
            vmat(nx*ny*(k-1)+nx*(j-1)+i,2)=myv(2,1);
            vmat(nx*ny*(k-1)+nx*(j-1)+i,3)=myv(3,1);
           
          else
            mat(nx*ny*(k-1)+nx*(j-1)+i,1)=1;
            mat(nx*ny*(k-1)+nx*(j-1)+i,4)=1;
            mat(nx*ny*(k-1)+nx*(j-1)+i,6)=1;  

            vmat(nx*ny*(k-1)+nx*(j-1)+i,1)=1;
            vmat(nx*ny*(k-1)+nx*(j-1)+i,2)=1;
            vmat(nx*ny*(k-1)+nx*(j-1)+i,3)=1;
          end
        end
    end
end

y=zeros(n,48);
sigma=0.5*eye(48)+0.5*ones(48);
sigma2=sigma^(1/2);

for i=1:n
    z=randn(48,1);
    y(i,:)=B*mat(i,:)'+sigma2*z; % generate the signal decay
end


end

