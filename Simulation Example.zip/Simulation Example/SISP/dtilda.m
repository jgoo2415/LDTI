function DD=dtilda(y,B)
DD=(B'*B)\(B'*y');
end



