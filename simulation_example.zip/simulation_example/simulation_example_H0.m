%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation Example Code for time-invariant curves under H0 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Theorem 1 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rng(2021)

nx=40; ny=40; nz=40; nt=19; n=nx*ny*nz*nt; 
t=(1:1:nt)/nt; % equally spaced time points

x0=[0.5*cos(0.3);0.5*sin(0.3);0.5]; 
delta=0.015; steps=30; % Euler's method 

h=0.0167;  % h should be within approximately 2epsilon/6=0.1/6.
beta=n*h^7; 

dir=48;% the number of gradient directions
[B, ~]=rotateb_new(dir); % create a 48*6 B-matrix
[dir, ~]=size(B); 

y_array=cell(nt,1); % each cell, a (nx*ny*nz)*48 matrix 
DD_array=cell(nt,1); % each cell, a 6*(nx*ny*nz) matrix 

for ind=1:nt
    [y_array{ind,1},~]=init_template1b(nx,ny,nz,B); 
    DD_array{ind,1}=dtilda(y_array{ind,1},B);  % ols of D  
end

v0=[1;1;1]; % an initial eigenvector
[xnhat,dnhat,dvdd,dddx,trH]=test_prep(n,nx,ny,nz,nt,DD_array(:,1),x0,t,delta,steps,beta,v0);

for ind=1:nt
    plot3(xnhat{ind}(1,:),xnhat{ind}(2,:),xnhat{ind}(3,:),'b') % estimated curves over time 
    hold on
end

view([0 90]) 

parform=2; % number of workers for parallel computing (increase when n increases)
dhat_array=dhat_all_fast(DD_array(:,1),n,nx,ny,nz,nt,beta,parform); % requires parallel computing
gam0gam0t=gam_prep(n,nx,ny,nz,nt,dhat_array,xnhat,t,steps,beta,y_array(:,1),B); % noise tensor estimation

[muhat,chat]=xnhatconf(dnhat,dvdd,dddx,gam0gam0t(:,1),trH,delta,steps,beta,nt);

ind=1; % at the 1st time point 
alpha=0.05; 
y=trackplot(xnhat{ind},muhat{ind},chat{ind},alpha,beta,n,steps); % 95% confindence ellipsoids

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Theorem 2 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

chi_null_svd=zeros(1,3);
ratio_svd=zeros(1,3);

a=1; b=19; % b>a+6 and nt is odd for the use of Simpson's 1/3 rule
wa=cell(1,3); wb=cell(1,3); wt=cell(1,3); % weight functions
wa{1}=[t(a);t(a);t(a)]; wb{1}=[t(b);t(b);t(b)]; wt{1}=ones(3,nt);  % linear 
wa{2}=[exp(t(a));exp(t(a));exp(t(a))]; wb{2}=[exp(t(b));exp(t(b));exp(t(b))]; wt{2}=[exp(t);exp(t);exp(t)]; % exponential
wa{3}=[1;1;1]; wb{3}=[1;1;1]; wt{3}=zeros(3,nt); % constant

m=2; % the number of singular values used
steps2=30; % the number of steps on the curve to test 

for rep=1:3
    what=W0(xnhat,a,b,t,steps2,wa{rep},wb{rep},wt{rep},n,h);
    covhat=cov0(chat,a,b,steps2,wa{rep},wb{rep});
    meanhat=mu0(muhat,a,b,t,steps2,wa{rep},wb{rep},wt{rep});
    diff=what(2:steps2+1,1)-meanhat(2:steps2+1,1);
    [U, S, V]=svd(covhat(2:steps2+1,2:steps2+1));
    J=U(:,1:m)*S(1:m,1:m)*V(:,1:m)'; % truncated singular value decomposition
            
    chi_null_svd(1,rep)=diff'*pinv(J,0.00000001)*diff;
    ratio_svd(1,rep)=sum(diag(S(1:m,1:m))/sum(diag(S)));
end 

chi_null_svd %#ok<NOPTS> % test statistic values across different weight functions
ratio_svd %#ok<NOPTS> % the proportion of leading singular values

chi2inv(0.95,m) % critical value to compare


