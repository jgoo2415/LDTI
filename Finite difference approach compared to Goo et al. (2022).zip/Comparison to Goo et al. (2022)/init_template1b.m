function y=init_template1b(nx,ny,nz,B)
n=nx*ny*nz;
loc=zeros(n,3);
mat=zeros(n,6);

for i=1:nx
    for j=1:ny
        for k=1:nz
            loc(nx*ny*(k-1)+nx*(j-1)+i,:)=[i/nx, j/ny, k/nz];
            v1=sqrt((i/nx)^2+(j/ny)^2);
% thickness of the fiber bundle is epsilon
            epsilon=0.05;
          if (abs(k/nz-0.5)<epsilon)&&(abs(v1-0.5)<epsilon)
              % 0.45 < sqrt((i/nx)^2+(j/ny)^2) < 0.55 
            myv=[(j/ny)/v1 (i/nx)/v1 0; -(i/nx)/v1 (j/ny)/v1 0; 0 0 1];
            mym=myv*diag([10,2,1])*myv';
            mat(nx*ny*(k-1)+nx*(j-1)+i,1)=mym(1,1);
            mat(nx*ny*(k-1)+nx*(j-1)+i,2)=mym(1,2);
            mat(nx*ny*(k-1)+nx*(j-1)+i,3)=mym(1,3);
            mat(nx*ny*(k-1)+nx*(j-1)+i,4)=mym(2,2);
            mat(nx*ny*(k-1)+nx*(j-1)+i,5)=mym(2,3);
            mat(nx*ny*(k-1)+nx*(j-1)+i,6)=mym(3,3);
           
          else
            mat(nx*ny*(k-1)+nx*(j-1)+i,1)=1;
            mat(nx*ny*(k-1)+nx*(j-1)+i,4)=1;
            mat(nx*ny*(k-1)+nx*(j-1)+i,6)=1;  
          end
        end
    end
end

y=zeros(n,48);
sigma=0.5*eye(48)+0.5*ones(48);
sigma2=sigma^(1/2);

for i=1:n
    z=randn(48,1);
    y(i,:)=B*mat(i,:)'+sigma2*z;
end

%gamgam0=(inv(B'*B))*B'*sigma*B*(inv(B'*B));
end

