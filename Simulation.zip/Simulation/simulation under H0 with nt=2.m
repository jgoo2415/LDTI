%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation Example Code for time-invariant curves under H0 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nx=50; ny=50; nz=50; nt=2; n=nx*ny*nz;
dir=48;% the number of gradient directions

delta=0.02; steps=15; % Euler's method 
h=0.0167;  % h should be within approximately 2epsilon/6=0.1/6.
beta=n*h^6;
h1=(n/beta)^(-1/8); 
h2=(n/beta)^(-1/9);  
a=[-1;1]; % x2-x1 % same as a=[1;-1];

x0=[0.5*cos(0.3);0.5*sin(0.3);0.5]; 

chi_null=zeros(1000,1);

parpool('Processes',28);

tic
parfor (nsim=1:1000,28)
rng(1234+nsim)

[B, ~]=rotateb_new(dir); % create a 48*6 B-matrix

y_array=cell(nt,1); % each cell, a (nx*ny*nz)*48 matrix 
DD_array=cell(nt,1); % each cell, a 6*(nx*ny*nz) matrix 


for q0=1:nt
    y_array{q0,1}=init_template1b(nx,ny,nz,B); 
    DD_array{q0,1}=dtilda(y_array{q0,1},B);  % ols of D  
end


[xnhat, dnhat, dvdd, dddx, trH]=xnhat_all2(nx,ny,nz,nt,DD_array,delta,steps,h,h1,h2,x0);

%figure(); hold on
%for q0=1:nt
%    plot3(xnhat{q0}(1,:),xnhat{q0}(2,:),xnhat{q0}(3,:),'b') % estimated curves over time 
%end
%hold off

%view([0 90]) 

dhat_array=dnhat_all_prep(DD_array(:,1),nx,ny,nz,nt,h); 
gam0gam0t=gamgamt_all_prep2(nx,ny,nz,nt,dhat_array,xnhat,steps,beta,y_array(:,1),B); 

[muhat,chat]=xnhatconf(dnhat,dvdd,dddx,gam0gam0t(:,1),trH,delta,steps,beta,nt);

%q0=2; % at the 1st time point 
%alpha=0.05; 
%y=trackplot(xnhat{q0},muhat{q0},chat{q0},alpha,beta,n,steps); % 95% confindence ellipsoids

w=a(1)*xnhat{1,1}+a(2)*xnhat{2,1};
wnhat=sqrt(n*h^2)*sum(w,1);

mu=a(1)*muhat{1,1}+a(2)*muhat{2,1};
muvec=sum(mu,1);

cov=a(1)^2*chat{1,1}+a(2)^2*chat{2,1};
covhat=zeros((1+steps),(1+steps));
for j=1:(1+steps)
    for k=1:(1+steps)
        covhat(j,k)=ones(1,3)*cov(:,:,j,k)*ones(3,1);
    end
end
diff=(wnhat(:,2:steps+1)-muvec(:,2:steps+1))';
P=covhat(2:steps+1,2:steps+1);
[U S V]=svds(P,2); 
chi_null(nsim,1)=diff'*pinv(U*S*V',10^-6)*diff;

end
toc

delete(gcp('nocreate'));

save('chinull_nt2.mat','chi_null')
