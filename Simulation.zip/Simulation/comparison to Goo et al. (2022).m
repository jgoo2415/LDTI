%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation Example Code for Comparison 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nx=50; ny=50; nz=50; nt=2; n=nx*ny*nz;
dir=48;% the number of gradient directions

delta=0.02; steps=15; % Euler's method 
h=0.0167;  % h should be within approximately 2epsilon/6=0.1/6.
beta=n*h^6;
h1=(n/beta)^(-1/8); 
h2=(n/beta)^(-1/9);  

x0=[0.5*cos(0.3);0.5*sin(0.3);0.5]; 

rng(1234)

[B, ~]=rotateb_new(dir); % create a 48*6 B-matrix

y_array=cell(nt,1); % each cell, a (nx*ny*nz)*48 matrix 
DD_array=cell(nt,1); % each cell, a 6*(nx*ny*nz) matrix 

for q0=1:nt
    y_array{q0,1}=init_template1b(nx,ny,nz,B); 
    DD_array{q0,1}=dtilda(y_array{q0,1},B);  % ols of D  
end

% ours % 

[xnhat, dnhat, dvdd, dddx, trH]=xnhat_all2(nx,ny,nz,nt,DD_array,delta,steps,h,h1,h2,x0); 
dhat_array=dnhat_all_prep(DD_array(:,1),nx,ny,nz,nt,h); 
gam0gam0t=gamgamt_all_prep2(nx,ny,nz,nt,dhat_array,xnhat,steps,beta,y_array(:,1),B); 

[muhat,chat]=xnhatconf(dnhat,dvdd,dddx,gam0gam0t(:,1),trH,delta,steps,beta,nt);



% Goo et al. (2022) %

beta % same 2.7115e-06
n=nx*ny*nz*nt;
h=(n/beta)^(-1/7);
h1=(n/beta)^(-1/9);
h2=(n/beta)^(-1/10);
t=(1:1:nt)/nt; % equally spaced time points

[xnhat2, dnhat2, dvdd2, dddx2, trH2]=xnhat_all2_Goo(n,nx,ny,nz,nt,DD_array,x0,t,delta,steps,beta);


dhat_array2=dnhat_all_prep_Goo(DD_array(:,1),nx,ny,nz,nt,beta); 
gam0gam0t2=gamgamt_all_prep2_Goo(nx,ny,nz,nt,dhat_array2,xnhat2,t,steps,beta,y_array(:,1),B); 

[muhat2,chat2]=xnhatconf_Goo(dnhat2,dvdd2,dddx2,gam0gam0t2(:,1),trH2,delta,steps,beta,nt);

% Time point 1
alpha=0.05;
figure(); hold on

y=trackplot(xnhat{1},muhat{1},chat{1},alpha,nx,ny,nz,beta,steps) % ours
y=trackplot2(xnhat2{1},muhat2{1},chat2{1},alpha,nx,ny,nz,nt,beta,steps) % Goo et al. (2022)

hold off

view([-12 50])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation Example Code for Comparison 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nx=50; ny=50; nz=50; nt=4; n=nx*ny*nz;
dir=48;% the number of gradient directions

delta=0.02; steps=15; % Euler's method 
h=0.0167;  % h should be within approximately 2epsilon/6=0.1/6.
beta=n*h^6;
h1=(n/beta)^(-1/8); 
h2=(n/beta)^(-1/9);  

x0=[0.5*cos(0.3);0.5*sin(0.3);0.5]; 

rng(1234)

[B, ~]=rotateb_new(dir); % create a 48*6 B-matrix

y_array=cell(nt,1); % each cell, a (nx*ny*nz)*48 matrix 
DD_array=cell(nt,1); % each cell, a 6*(nx*ny*nz) matrix 

for q0=1:nt
    y_array{q0,1}=init_template1b(nx,ny,nz,B); 
    DD_array{q0,1}=dtilda(y_array{q0,1},B);  % ols of D  
end

% ours % 

[xnhat, dnhat, dvdd, dddx, trH]=xnhat_all2(nx,ny,nz,nt,DD_array,delta,steps,h,h1,h2,x0); 
dhat_array=dnhat_all_prep(DD_array(:,1),nx,ny,nz,nt,h); 
gam0gam0t=gamgamt_all_prep2(nx,ny,nz,nt,dhat_array,xnhat,steps,beta,y_array(:,1),B); 

[muhat,chat]=xnhatconf(dnhat,dvdd,dddx,gam0gam0t(:,1),trH,delta,steps,beta,nt);



% Goo et al. (2022) %

beta % same 2.7115e-06
n=nx*ny*nz*nt;
h=(n/beta)^(-1/7);
h1=(n/beta)^(-1/9);
h2=(n/beta)^(-1/10);
t=(1:1:nt)/nt; % equally spaced time points

[xnhat2, dnhat2, dvdd2, dddx2, trH2]=xnhat_all2_Goo(n,nx,ny,nz,nt,DD_array,x0,t,delta,steps,beta);


dhat_array2=dnhat_all_prep_Goo(DD_array(:,1),nx,ny,nz,nt,beta); 
gam0gam0t2=gamgamt_all_prep2_Goo(nx,ny,nz,nt,dhat_array2,xnhat2,t,steps,beta,y_array(:,1),B); 

[muhat2,chat2]=xnhatconf_Goo(dnhat2,dvdd2,dddx2,gam0gam0t2(:,1),trH2,delta,steps,beta,nt);

% Time point 1
alpha=0.05;
figure(); hold on

y=trackplot(xnhat{1},muhat{1},chat{1},alpha,nx,ny,nz,beta,steps) % ours
y=trackplot2(xnhat2{1},muhat2{1},chat2{1},alpha,nx,ny,nz,nt,beta,steps) % Goo et al. (2022)

hold off

view([-12 50])


